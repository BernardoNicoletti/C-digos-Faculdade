public class Uni5Exe29 {
    public static void main(String[] args) {
        System.out.println("NÂO É PARA FAZER");       
    }
}